start cli.exe cert.txt

